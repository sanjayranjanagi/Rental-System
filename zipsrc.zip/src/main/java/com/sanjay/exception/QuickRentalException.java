package com.sanjay.exception;

public class QuickRentalException extends Exception{

	private static final long serialVersionUID=1L;
	
	public QuickRentalException(String message) {
		super(message);
	}
}
