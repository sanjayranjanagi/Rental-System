package com.sanjay.utility;

public class LoggingAspect {

}
