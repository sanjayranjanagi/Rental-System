package com.sanjay.utility;

public class ErrorInfo {

}
