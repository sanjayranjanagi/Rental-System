package com.sanjay.dto;

public enum VehicleTypeAndStatus {
	BIKE, SCOOTER, EV, CAR, BOOKED, AVAILABLE
}
